#!/bin/bash
./imageOutliner.sh -itestInput.png -otestOutput -m10101010 -cFF0000FF
exit $?;
